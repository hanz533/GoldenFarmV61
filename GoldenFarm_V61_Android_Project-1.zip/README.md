# Golden Farm V61 Android project

This is a basic Android WebView wrapper for the V60 HTML demo. It is a test build, not a release-ready app. It contains no real ad SDK, payment, or withdrawal processing.

## Build using GitHub Actions
1. Create a repository on GitHub and upload these project files.
2. Open the repository's Actions tab and run `Build Golden Farm APK` (or push a commit).
3. When the workflow succeeds, open the run, download the `GoldenFarm-debug-apk` artifact, and install it only on a device you control.

Review app permissions and functionality before installing or distributing.
