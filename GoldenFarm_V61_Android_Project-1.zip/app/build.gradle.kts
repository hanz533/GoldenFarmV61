plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.goldenfarm.app"; compileSdk = 35
 defaultConfig { applicationId = "com.goldenfarm.app"; minSdk = 23; targetSdk = 35; versionCode = 61; versionName = "61" } }
