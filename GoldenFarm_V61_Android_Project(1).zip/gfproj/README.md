# Golden Farm V61 Android starter

This is a minimal Android WebView wrapper starter and GitHub Actions workflow to build a debug APK.

**Important:** This starter does not contain the user's original V60 HTML game. Its asset page is a simple placeholder. Replace `app/src/main/assets/index.html` with the actual game's HTML before expecting the game features to appear. Ads, sales, and withdrawals are not implemented.

Build with GitHub Actions: commit files, open Actions, run or wait for the workflow, and download the APK artifact after a successful run.
